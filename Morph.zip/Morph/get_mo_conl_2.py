import re
import subprocess

# Files Location
morphbin = 'tam_apertium_v2.1.moobj'
inputFile = 'input_files/sample_2.txt'

# Read input file
fp1 = open(inputFile, "r", encoding='utf-8', errors='ignore')
lines = fp1.read().split("\n")
fp1.close()

result = {}


def tokenizer(input_tokens):
    fpw = open("in.tmp", "w", encoding='utf-8')
    for input_token in input_tokens:
        fpw.write(input_token + "\n")
    fpw.close()

    pid = subprocess.Popen([command],
                           shell=True,
                           executable="/bin/bash",
                           stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE
                           )
    (output, err) = pid.communicate()
    pid.wait()
    fp2 = open("out.tmp", "r", encoding='utf-8')
    out_file = fp2.read().strip().split("\n")
    fp2.close()
    stared_words = []
    for line in out_file:
        if re.search(r'\*', line) or re.search(r'\$\^', line):
            stared_words.append(line)
        else:
            line = line.strip().split('/')
            if len(line) > 1:
                line[0] = line[0].replace('^', '')
                result[f"{line[0]}"] = line[1:len(line)]

    return stared_words, result


def check_star_word(text):
    fpw = open("in.tmp", "w", encoding='utf-8')
    fpw.write(text + '\n')
    fpw.close()

    pid = subprocess.Popen([command],
                           shell=True,
                           executable="/bin/bash",
                           stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE
                           )
    (output, err) = pid.communicate()
    pid.wait()
    fp2 = open("out.tmp", "r", encoding='utf-8')
    out_file = fp2.read().strip().split("\n")
    fp2.close()
    return out_file[0]


# execution command
command = 'lt-proc -c ' + morphbin + " < in.tmp > out.tmp"
input_tokens = []

for line in lines:
    if line == "":
        continue
    line = line.strip()
    arr = line.split('\t')
    if len(arr) > 1 and not re.search(r'\t\-', line) and not re.search(r'^#|\.\.\.|\/', line):
        input_token = re.sub(r'@', '', arr[1])
        input_tokens.append(input_token)
        input_tokens = list(set(input_tokens))
    else:
        if len(arr) > 1 and re.search(r'(\@|\/|\.\.\.)', arr[1]):
            result[f"{arr[1]}"] = [f"{arr[0]}\t{arr[1]}\t{arr[2]}\t^{arr[1]}/{arr[1]}<lcat:punc>$"]
'''
Total Words = 13574
Unique Words = 4304
'''

print("U-Total - ", len(input_tokens))

stared_words, result = tokenizer(input_tokens)


for key, value in result.items():
    print(f"{key}\t{value}")
print("----------------")
# print("len(result) - ", len(result))
# print("len(stared_words) - ", len(stared_words))

for word in stared_words:
    arr = word.strip().split('/')
    arr[0] = arr[0].replace('^', '')
    clitic_flag, sandhi_flag, pro_clitic_flag = 0, 0, 0
    try:
        pos = arr[2]
    except:
        pos = "POSUNK"
    if re.search(r'\*', word) or re.search(r'\$\^', word):
        if re.search(r'[kcwp]$', arr[0]):
            replaced_token = re.sub(r'[kcwp]$', r'', arr[0])
            kctwp_token = re.sub(r'^.*([kcwp])$', r'\1', arr[0])
            replaced_token = re.sub(r'@', '', replaced_token)
            result_word = check_star_word(replaced_token)
            print("R1 - ", result_word)
            if re.search(r'\*', result_word) or re.search(r'\$\^', result_word):
                dont_print = 0
            else:
                result_word = re.sub(r'<suffix:(.*?)>', r'<suffix:\1><sandhi:' + kctwp_token + '>', result_word)
                result[f"{arr[0]}"] = [f"{arr[0]}\t{arr[1]}\t{pos}\t{result_word}"]
                sandhi_flag = 1

        if (re.search(r'[iIE]yum$|[iIE]yA$|[iIE]ye$|[iIE]yo$', arr[0]) or re.search(
                r'([aAeoOV]+)vum$|([aAeoOV]+)vA$|([aAeoOV]+)ve$|([aAeoOV]+)vo$', arr[0]) or re.search(
            r'([^aeiouAEIOV]+)um$|([^aeiouAEIOV]+)A$|([^aeiouAEIOV]+)e$|([^aeiouAEIOV]+)o$', arr[0] or re.search(
                r'[iIE]yeye$|([aAeoOV]+)veye$|([^aeiouAEIOV]+)eye$|[iIE]yume$|([aAeoOV]+)vume$|([^aeiouAEIOV]+)ume$',
                arr[0])) and sandhi_flag == 0):
            if re.search(r'ume$', arr[0]):
                replaced_token = re.sub(r'([vy]?)ume$', r'', arr[0])
                clitic_token = re.sub(r'^(.*)([vy]?)ume$', r'um_e', arr[0])
                replaced_token = re.sub(r'@', '', replaced_token)
            elif re.search(r'um$', arr[0]):
                replaced_token = re.sub(r'([vy]?)um$', r'', arr[0])
                clitic_token = re.sub(r'^(.*)([vy]?)um$', r'um', arr[0])
                replaced_token = re.sub(r'@', '', replaced_token)
            elif re.search(r'A$', arr[0]):
                replaced_token = re.sub(r'([vy]?)A$', r'', arr[0])
                clitic_token = re.sub(r'^(.*)([vy]?)A$', r'A', arr[0])
                replaced_token = re.sub(r'@', '', replaced_token)
            elif re.search(r'eye$', arr[0]):
                replaced_token = re.sub(r'([vy]?)eye$', r'', arr[0])
                clitic_token = re.sub(r'^(.*)([vy]?)eye$', r'e_e', arr[0])
                replaced_token = re.sub(r'@', '', replaced_token)
            elif re.search(r'e$', arr[0]):
                replaced_token = re.sub(r'([vy]?)e$', r'', arr[0])
                clitic_token = re.sub(r'^(.*)([vy]?)e$', r'e', arr[0])
                replaced_token = re.sub(r'@', '', replaced_token)
            elif re.search(r'o$', arr[0]):
                replaced_token = re.sub(r'([vy]?)o$', r'', arr[0])
                clitic_token = re.sub(r'^(.*)([vy]?)o$', r'o', arr[0])
                replaced_token = re.sub(r'@', '', replaced_token)
            result_word = check_star_word(replaced_token)
            print("R2 - ", result_word)

            if re.search(r'\*', result_word) or re.search(r'\$\^', result_word):
                if (re.search(r'([^aeiouAEIOV]+)um$|([^aeiouAEIOV]+)A$|([^aeiouAEIOV]+)e$|([^aeiouAEIOV]+)o$',
                              arr[0])):
                    if re.search(r'um$', arr[0]):
                        replaced_token = re.sub(r'm$', r'', arr[0])
                        clitic_token = re.sub(r'^(.*)m$', r'um', arr[0])
                        replaced_token = re.sub(r'@', '', replaced_token)
                    elif re.search(r'A$', arr[0]):
                        replaced_token = re.sub(r'A$', r'u', arr[0])
                        clitic_token = re.sub(r'^(.*)A$', r'A', arr[0])
                        replaced_token = re.sub(r'@', '', replaced_token)
                    elif re.search(r'e$', arr[0]):
                        replaced_token = re.sub(r'e$', r'u', arr[0])
                        clitic_token = re.sub(r'^(.*)e$', r'e', arr[0])
                        replaced_token = re.sub(r'@', '', replaced_token)
                    elif re.search(r'o$', arr[0]):
                        replaced_token = re.sub(r'o$', r'u', arr[0])
                        clitic_token = re.sub(r'^(.*)o$', r'o', arr[0])
                        replaced_token = re.sub(r'@', '', replaced_token)
                    result_word = check_star_word(replaced_token)
                    print("R3 - ", result_word)

                    if re.search(r'\*', result_word) and sandhi_flag == 0:
                        dont_print = 0
                    else:
                        result_word = re.sub(r'<suffix:(.*?)>', r'<suffix:\1><clitic:' + clitic_token + '>',
                                             result_word)
                        result[f"{arr[0]}"] = [f"{arr[0]}\t{arr[1]}\t{pos}\t{result_word}"]
                        clitic_flag = 1
            else:
                result_word = re.sub(r'<suffix:(.*?)>', r'<suffix:\1><clitic:' + clitic_token + '>', result_word)
                result[f"{arr[0]}"] = [f"{arr[0]}\t{arr[1]}\t{pos}\t{result_word}"]
                clitic_flag = 1
        if (re.search(
                r'^ak|^ik|^eVk|^ac|^eVc|^ic|^aw|^eVw|^iw|^an|^in|^eVn|^ap|^eVp|^ip|^am|^eVm|^im|^av|^avv|^eVv|^eVvv|^iv|^ivv',
                arr[0]) and sandhi_flag == 0 and clitic_flag == 0):
            replaced_token = re.sub(
                r'^ak|^ik|^eVk|^ac|^eVc|^ic|^aw|^eVw|^iw|^an|^in|^eVn|^ap|^eVp|^ip|^am|^eVm|^im|^av|^avv|^eVv|^eVvv|^iv|^ivv',
                r'', arr[0])
            pro_clitic_token = re.sub(
                r'(^ak|^ik|^eVk|^ac|^eVc|^ic|^aw|^eVw|^iw|^an|^in|^eVn|^ap|^eVp|^ip|^am|^eVm|^im|^av|^avv|^eVv|^eVvv|^iv|^ivv).*',
                r'\1', arr[0])
            replaced_token = re.sub(r'@', '', replaced_token)
            if replaced_token == "":
                replaced_token = arr[0]
            result_word = check_star_word(replaced_token)
            print("R4 - ", result_word)
            if re.search(r'\*', result_word) or re.search(r'\$\^', result_word):
                result[f"{arr[0]}"] = [f"{arr[0]}\t{arr[1]}\t{pos}\tMOUNK"]
            else:
                result_word = re.sub(r'<suffix:(.*?)>', r'<suffix:\1><pro_clitic:' + pro_clitic_token + '>$',
                                     result_word)
                result[f"{arr[0]}"] = [f"{arr[0]}\t{arr[1]}\t{pos}\t{result_word}"]
                pro_clitic_flag = 1
        else:
            if sandhi_flag == 0 and clitic_flag == 0 and pro_clitic_flag == 0:
                if re.search(r'\$\^', arr[1]):

                    print(f"{arr[0]}\t{arr[1]}\t{pos}\tMOUNK")
                    print(word)
                    result[f"{arr[0]}"] = [f"{arr[0]}\t{arr[1]}\t{pos}\tMOUNK"]
    else:
        result[f"{arr[0]}"] = [f"{arr[0]}\t{arr[1]}\t{pos}\t{word}"]

print(len(result))
print("----------------")
for key, value in result.items():
    print(f"{key}\t{value}")
